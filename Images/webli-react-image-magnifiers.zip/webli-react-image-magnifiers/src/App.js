import React from 'react';
import GlassMagnifierExample from './component/GlassMagnifierExample'
import MagnifierExample from './component/MagnifierExample'
import PictureinPictureExample from './component/PictureinPictureExample'
import SideBySideMagnifierExample from './component/SideBySideMagnifierExample'

function App() {
  return (
    <div className="App">
     <GlassMagnifierExample></GlassMagnifierExample>
    
    </div>
  );
}

export default App;
