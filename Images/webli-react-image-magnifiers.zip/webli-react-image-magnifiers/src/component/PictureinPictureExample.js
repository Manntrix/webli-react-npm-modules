import React, { Component } from 'react'
import { PictureInPictureMagnifier} from "react-image-magnifiers";
import image from './image.jpg'
import largeImage from './largeimage.jpg'

export default class PictureinPictureExample extends Component {
    render() {
        return (
            <div>
                <PictureInPictureMagnifier
                className="input-position"
                imageSrc={image}
                largeImageSrc={largeImage}
                previewOpacity={0.3}
              />
            </div>
        )
    }
}
