import React, { Component } from 'react'
import {SideBySideMagnifier} from "react-image-magnifiers";
import image from './image.jpg'
import largeImage from './largeimage.jpg'

export default class SideBySideMagnifiereXAMPLE extends Component {
    render() {
        return (
            <div>
                  <SideBySideMagnifier
  imageSrc={image}
  imageAlt="Example"
  largeImageSrc={largeImage}
  overlayOpacity={0.3}
  alwaysInPlace={false}
  transitionSpeed={0.2}
/>
            
            </div>
        )
    }
}
