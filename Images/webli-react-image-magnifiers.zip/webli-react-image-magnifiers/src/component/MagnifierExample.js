import React, { Component } from 'react'
import { Magnifier, MOUSE_ACTIVATION, TOUCH_ACTIVATION} from "react-image-magnifiers";
import image from './image.jpg'
import largeImage from './largeimage.jpg'

export default class MagnifierExample extends Component {
    render() {
        return (
            <div>
                <Magnifier
  imageSrc={image}
  imageAlt="Example"
  largeImageSrc={largeImage}
  mouseActivation={MOUSE_ACTIVATION.DOUBLE_CLICK}
  touchActivation={TOUCH_ACTIVATION.DOUBLE_TAP}
/>
            </div>
        )
    }
}
