import React, { Component } from 'react'
import {GlassMagnifier} from "react-image-magnifiers";
import image from './image.jpg'
import largeImage from './largeimage.jpg'

export default class GlassMagnifierExample extends Component {
    render() {
        return (
            <div>
                <GlassMagnifier
  imageSrc={image}
  imageAlt="Example"
  largeImageSrc={largeImage}
/>
            </div>
        )
    }
}
