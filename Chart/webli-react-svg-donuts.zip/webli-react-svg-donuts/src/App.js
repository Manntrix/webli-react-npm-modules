import React from 'react';
import Simple from './component/simple'
import Complex from './component/complex'

function App() {
  return (
    <div className="App">
     
      <Complex></Complex>
    </div>
  );
}

export default App;
