import React, { Component } from 'react'
import Donut from 'react-svg-donuts';

export default class simple extends Component {
    render() {
        const renderProgress = progress => <strong>{progress}%</strong>;
        return (
           
               <React.Fragment>
		<Donut progress={0} onRender={renderProgress} />
		<Donut progress={50} onRender={renderProgress} />
		<Donut progress={100} onRender={renderProgress} />
		<Donut progress={-30} onRender={renderProgress} />
	</React.Fragment> 
          
        )
    }
}
