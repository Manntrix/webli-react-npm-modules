import React, { Component } from 'react'

import ComplexDonut from 'react-svg-donuts/dist/complex';

export default class complex extends Component {
    render() {
        return (
            <div>
                <ComplexDonut
        size={200}
        radius={80}
        segments={[
            {
                color: '#FF8A80',
                value: 230
            },
            {
                color: '#FF80AB',
                value: 308
            },
            {
                color: '#B9F6CA',
                value: 520
            },
            {
                color: '#B388FF',
                value: 130
            },
            {
                color: '#8C9EFF',
                value: 200
            }
        ]}
        thickness={40}
        startAngle={-90}
    />
            </div>
        )
    }
}
